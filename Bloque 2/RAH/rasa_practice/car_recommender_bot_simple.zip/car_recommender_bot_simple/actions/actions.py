from rasa_sdk import Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.forms import FormValidationAction, Action
from rasa_sdk.events import SlotSet
import pandas as pd
import numpy as np
import smtplib
import random
import ssl
import os
import re

class ResetSlots(Action):

    def name(self):
        return  "reset"
    
    async def run(self, dispatcher, tracker, domain):
        return [
            SlotSet("km_driven_per_day", None),
            SlotSet("has_garage", None),
            SlotSet("yearly_income", None),
            SlotSet("constant_payments", None),
        ]
    
class ComputeBestFuelType(Action):

    def name(self):
        return "compute_best_fuel_type"
    
    async def run(self, dispatcher, tracker, domain):

        has_garage = tracker.get_slot('has_garage') == 'yes'
        km_driven_per_day = int(tracker.get_slot('km_driven_per_day'))

        if has_garage and float(km_driven_per_day) < 100:
            dispatcher.utter_message(text=f'Since you have a garage and your daily mileage is not really high, you can go for an Electric car.')
            return []
        
        gas_price = 1.6 #€/L
        diese_price = 1.495 #€/L

        gas_avg_consumption = 7.5 #L/100km
        diesel_avg_consumption = 5.5 #L/100km

        database = pd.read_csv(f'{os.getcwd()}/actions/Database.csv')

        diesel_car_avg_price = np.mean(database.loc[database['fuel'] == 'Diesel']['selling_price']) * 0.011
        petrol_car_avg_price = np.mean(database.loc[database['fuel'] == 'Petrol']['selling_price']) * 0.011
        
        diesel_overprice = diesel_car_avg_price - petrol_car_avg_price
        diesel_savings_per_km = (gas_price * gas_avg_consumption - diese_price * diesel_avg_consumption)/100 # €/1km

        years_til_benefit = diesel_overprice/(km_driven_per_day*365*diesel_savings_per_km)

        if years_til_benefit > 10: #petrol
            dispatcher.utter_message(text=f'On average, Diesel cars cost {diesel_overprice:.2f}€ more, although them consume less and this fuel is cheaper. \nGiven the actual fuel price, you will get the return of investment in {years_til_benefit:.0f} years. That\'s more than the recommended value (10). \nSo i suggest you to get a Petrol car.')
            return []
        else: #diesel
            dispatcher.utter_message(text=f'On average, Diesel cars cost {diesel_overprice:.2f}€ more, although them consume less and this fuel is cheaper. \nGiven the actual fuel price, you will get the return of investment in {years_til_benefit:.0f} years. That\'s less than the recommended value (10). \nSo i suggest you to get a Diesel car.')
            return []


class ComputeBestMaxPrice(Action):

    def name(self):
        return "compute_best_max_price"
    
    async def run(self, dispatcher, tracker, domain):
        yearly_income = tracker.get_slot('yearly_income')
        constant_payments = tracker.get_slot('constant_payments')

        monthly_payment = yearly_income/12
        monthly_remains = monthly_payment - constant_payments

        car_monthly_spent = monthly_remains/3

        car_total_value = car_monthly_spent * 12 * 7
        dispatcher.utter_message(text=f'Based on your current financial conditions, you should not spend more than {car_monthly_spent:.2f}€ each month in the car. \nSo to completelly pay it in 7 years, you have a maximum price of {car_total_value:.2f}')

        return []
    
class ValidateInfoFuelTypeForm(FormValidationAction):
    def name(self):
        return "validate_info_fuel_type_form"

    def validate_km_driven_per_day(self, value, dispatcher, tracker, domain):

        if int(value) <= 0:
            dispatcher.utter_message(response="utter_incorrect_km_driven_per_day")
            return {"km_driven_per_day": None}
        else:
            return {"km_driven_per_day": value}

class ValidateInfoIncomeForm(FormValidationAction):
    def name(self):
        return "validate_info_income_form"

    def validate_yearly_income(self, value, dispatcher, tracker, domain):

        if int(value) <= 0:
            dispatcher.utter_message(response="utter_positive_amount")
            return {"yearly_income": None}
        else:
            return {"yearly_income": value}
        
    def validate_constant_payments(self, value, dispatcher, tracker, domain):

        if int(value) < 0:
            dispatcher.utter_message(response="utter_positive_amount")
            return {"constant_payments": None}
        else:
            return {"constant_payments": value}
